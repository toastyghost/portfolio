<?php 
require_once('mimik/mimik_configuration/the_system_settings.config.php');

include($THE_BASE_URL . "/mimik/mimik_live_data/view.php?id=1&record_id=1");
?>
